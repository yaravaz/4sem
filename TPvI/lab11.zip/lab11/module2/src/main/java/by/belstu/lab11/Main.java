package by.belstu.lab11;

public class Main {
    public static void main(String [] args){
        Class some = new Class("sdf", 4, "qwerty");
        System.out.println(some);
    }
}
